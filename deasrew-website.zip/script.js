let cart=[];

window.addEventListener('DOMContentLoaded',()=>{
 document.querySelector('[data-open-cart]').onclick=openCart;
 updateCartDisplay();
});

function addToCart(name,price){
 cart.push({name,price});
 updateCartDisplay();
}

function openCart(){ document.getElementById('cart').style.right='0'; }
function closeCart(){ document.getElementById('cart').style.right='-400px'; }

function updateCartDisplay(){
 const list=document.getElementById('cart-items'); if(!list) return;
 list.innerHTML='';
 cart.forEach((i,idx)=>{
   list.innerHTML+=`<li>${i.name} - $${i.price}</li>`;
 });
 document.getElementById('cart-count').innerText=cart.length;
}
